<?php
$id_telegram = "5769067353";
$id_botTele  = "6242167448:AAGCRNiJuz1SUiwHbPRMSRkY9__V_GT0yWQ";
?>
